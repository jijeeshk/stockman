import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

import { DatapartsService } from '../../services/dataparts.service';
import { Alert } from 'selenium-webdriver';


@Component({
  selector: 'app-add-purchaseparts',
  templateUrl: './add-purchaseparts.component.html',
  styleUrls: ['./add-purchaseparts.component.css']
})
export class AddPurchasepartsComponent implements OnInit {

  _payLoad: any;
  _purchaseId = this._route.snapshot.params.id
  _purchaseparts: any;
  allParts: any;
  _part: any;
  _oldPartCount: any;
  selectedPart: any;

  constructor(
    private _route: ActivatedRoute,
    private _dataService: DatapartsService
  ) { }

  addPurchasePartForm = new FormGroup({
    partId: new FormControl(''),
    partCountVolume: new FormControl(''),
    partPrice: new FormControl(''),
  });

  ngOnInit() {
    this.getAllParts();
    this._dataService.gtPurchasePartsByID(this._purchaseId)
      .subscribe(response => this._purchaseparts = response);
  }

  getAllParts() {
    this._dataService.getParts()
      .subscribe(data => this.allParts = data);
  }

  public selected(value: any): void {
    this.selectedPart = value;
  }

  savePurchasePart() {
    this._payLoad = this.addPurchasePartForm.value;
    this._payLoad['purchaseid'] = this._purchaseId;
    this._payLoad['partName'] = this.selectedPart.partName;
    this._payLoad = JSON.stringify(this._payLoad);

    this._dataService.postPurchaseParts(this._payLoad)
      .subscribe(success => {
        console.log(success);
        this.updateStock(this._payLoad);
      })
  }

  updateStock(_payLoad) {


    var _tempStockObj = JSON.parse(_payLoad);

    this._dataService.getstockBypartId(_tempStockObj.partId)
      .subscribe(
        (data) => {
          this._part = data;
          if (isEmpty(this._part)) {
            //alert('Part does not exist');
            this.addstock(_payLoad);
          } else {
            //alert('Part exist, ID IS ' + _tempStockObj.partId);
            this._oldPartCount = this._part[0].partCountVolume;
            this.incrementStock(_payLoad, _tempStockObj.partId, this._oldPartCount);
          }

        }
      );

    function isEmpty(obj) {
      for (var key in obj) {
        if (obj.hasOwnProperty(key))
          return false;
      }
      return true;
    }
  }

  addstock(_payLoad) {
    var stockObj = {};
    var _tempStockObj = JSON.parse(_payLoad);
    stockObj['partId'] = _tempStockObj.partId;
    stockObj['partCountVolume'] = _tempStockObj.partCountVolume;
    stockObj['partName'] = _tempStockObj.partName;
    stockObj = JSON.stringify(stockObj);
    this._dataService.postStock(stockObj)
      .subscribe(
        success => {
          alert('Stock created suceesfully.');
        }
      );
  }

  incrementStock(_payLoad, updateid, oldcount) {
    var _tempStockObjn = JSON.parse(_payLoad);
    var _updateIdd = updateid;
    var stockpartid = _tempStockObjn.partId;
    var _oldcount = oldcount;

    var stockIncreObject = {};
    stockIncreObject['partId'] = _tempStockObjn.partId;
    stockIncreObject['partCountVolume'] = Number(_tempStockObjn.partCountVolume) + Number(_oldcount);
    stockIncreObject['partName'] = _tempStockObjn.partName;
    stockIncreObject = JSON.stringify(stockIncreObject);

    this._dataService.editStock(stockIncreObject, _updateIdd)
      .subscribe(
        success => {
          alert('Stock updated successfully');
        }
      )
  }
}

