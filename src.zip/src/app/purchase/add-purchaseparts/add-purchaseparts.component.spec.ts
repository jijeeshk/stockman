import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddPurchasepartsComponent } from './add-purchaseparts.component';

describe('AddPurchasepartsComponent', () => {
  let component: AddPurchasepartsComponent;
  let fixture: ComponentFixture<AddPurchasepartsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddPurchasepartsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddPurchasepartsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
