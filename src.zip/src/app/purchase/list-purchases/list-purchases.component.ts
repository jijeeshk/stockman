import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { DatapartsService } from '../../services/dataparts.service';

@Component({
  selector: 'app-list-purchases',
  templateUrl: './list-purchases.component.html',
  styleUrls: ['./list-purchases.component.css']
})
export class ListPurchasesComponent implements OnInit {

  private purchases = [];

  constructor(
    private _dataPartsService: DatapartsService,
    private router: Router
  ) { }

  ngOnInit() {
    this._dataPartsService.getPurchases()
      .subscribe(data => this.purchases = data);
  }

  mangaPurchaseParts(purchase) {
    this.router.navigate(['add-purchase-parts', purchase.id])
  }
}
