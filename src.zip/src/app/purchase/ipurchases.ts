export interface IPurchases {
    id: number,
    supplier: string,
    amount: string
}
