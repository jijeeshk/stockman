import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, } from '@angular/forms';
import { AlertsService } from 'angular-alert-module';

import { DatapartsService } from '../../services/dataparts.service';

@Component({
  selector: 'app-add-purchase',
  templateUrl: './add-purchase.component.html',
  styleUrls: ['./add-purchase.component.css']
})
export class AddPurchaseComponent implements OnInit {
  _payLoad: any;

  constructor(
    private _dataService: DatapartsService,
    private alerts: AlertsService,
  ) { }

  ngOnInit() {
  }

  addPurchaseForm = new FormGroup({
    purchaseDate: new FormControl(''),
    purchaseDistributor: new FormControl(''),
    purchaseBillNo: new FormControl(''),
    purchaseBillAmt: new FormControl('')
  });

  savePurchase() {
    this._payLoad = JSON.stringify(this.addPurchaseForm.value);
    this._dataService.postPurchases(this._payLoad)
      .subscribe(
        (response) => {
          this.alerts.setMessage('New part saved successfully!', 'success');
        },
        error => {
          console.log("Error", error);
        }
      )
  }
}
