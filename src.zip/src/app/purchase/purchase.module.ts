import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { AppRoutingModule } from '../app-routing.module';

import { AddPurchaseComponent } from './add-purchase/add-purchase.component';
import { ListPurchasesComponent } from './list-purchases/list-purchases.component';
import { AddPurchasepartsComponent } from './add-purchaseparts/add-purchaseparts.component';

@NgModule({
  imports: [
    CommonModule,
    AppRoutingModule,
    ReactiveFormsModule,
    NgSelectModule,
    NgbModule
  ],
  declarations: [AddPurchaseComponent, ListPurchasesComponent, AddPurchasepartsComponent]
})
export class PurchaseModule { }
