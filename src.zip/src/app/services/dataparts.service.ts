import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

import { IParts } from '../parts/iparts';
import { IPurchases } from '../purchase/ipurchases';
import { IProducts } from '../products/iproducts';

@Injectable({
  providedIn: 'root'
})
export class DatapartsService {

  private _partsUrl = 'http://localhost:3000/parts';
  private _delPartURL;
  private _editPartURL = '';
  private _getPartURL = '';
  private _getPartURLn;

  private _purchasesUrl = 'http://localhost:1301/purchases';
  private _purchasepartsUrl = 'http://localhost:1307/purchaseparts';

  private _productUrl = 'http://localhost:1302/products';
  private _productPartsUrl = 'http://localhost:1305/prodparts';

  private _ordersUrl = 'http://localhost:1306/orders';

  private _stockUrl = 'http://localhost:1308/stock';
  _editStockUrl: any;

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  constructor(
    private _http: HttpClient
  ) { }

  //Parts
  getParts(): Observable<IParts[]> {
    return this._http.get<IParts[]>(this._partsUrl);
  }

  postPart(_payload: IParts[]): Observable<IParts[]> {
    return this._http.post<IParts[]>(this._partsUrl, _payload, this.httpOptions);
  }

  deletPart(part): Observable<{}> {
    this._delPartURL = this._partsUrl + '/' + part.id;
    return this._http.delete(this._delPartURL, this.httpOptions);
  }

  getPartById(id: number): Observable<IParts[]> {
    this._getPartURL = this._partsUrl + '/' + id;
    return this._http.get<IParts[]>(this._getPartURL);
  }

  editPart(part, id): Observable<{}> {
    this._editPartURL = this._partsUrl + '/' + id;
    return this._http.put(this._editPartURL, part, this.httpOptions);
  }

  //Purchases
  getPurchases(): Observable<IPurchases[]> {
    return this._http.get<IPurchases[]>(this._purchasesUrl);
  }

  postPurchases(_payload: IPurchases): Observable<IPurchases[]> {
    return this._http.post<IPurchases[]>(this._purchasesUrl, _payload, this.httpOptions);
  }

  postPurchaseParts(_payload): Observable<any> {
    return this._http.post(this._purchasepartsUrl, _payload, this.httpOptions);
  }

  gtPurchasePartsByID(purchaseid) {
    return this._http.get(this._purchasepartsUrl + '?purchaseid=' + purchaseid)
  }

  //stocks  
  getstockBypartId(id: number): Observable<any> {
    this._getPartURL = this._stockUrl + '?partId=' + id;
    return this._http.get(this._getPartURL);
  }

  postStock(_payload) {
    return this._http.post(this._stockUrl, _payload, this.httpOptions);
  }

  editStock(part, id): Observable<{}> {
    this._editStockUrl = this._stockUrl + '/' + id;
    return this._http.put(this._editStockUrl, part, this.httpOptions);
  }

  //Products
  getProducts(): Observable<IProducts[]> {
    return this._http.get<IProducts[]>(this._productUrl);
  }

  postProducts(_payload: IProducts): Observable<IProducts[]> {
    return this._http.post<IProducts[]>(this._productUrl, _payload, this.httpOptions);
  }

  //Product parts
  getproductParts() {
    return this._http.get(this._productPartsUrl);
  }

  getProductPartsById(prodId: number): Observable<IParts[]> {
    this._getPartURLn = this._productPartsUrl + '?prodId=' + prodId;
    return this._http.get<IParts[]>(this._getPartURLn);
  }

  postProductsParts(_payload): Observable<any> {
    return this._http.post(this._productPartsUrl, _payload, this.httpOptions);
  }

  editProductsParts(newObj, id): Observable<{}> {
    this._editPartURL = this._productPartsUrl + '/' + id;
    return this._http.put(this._editPartURL, newObj, this.httpOptions);
  }

  //Assembly Orders
  getAssemblyOrders() {
    return this._http.get(this._ordersUrl);
  }
  postAssemblyOrder(_payload): Observable<any> {
    return this._http.post(this._ordersUrl, _payload, this.httpOptions);
  }

}
