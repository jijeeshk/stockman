import { TestBed, inject } from '@angular/core/testing';

import { DatapartsService } from './dataparts.service';

describe('DatapartsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DatapartsService]
    });
  });

  it('should be created', inject([DatapartsService], (service: DatapartsService) => {
    expect(service).toBeTruthy();
  }));
});
