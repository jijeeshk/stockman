import { Component, OnInit } from '@angular/core';

import { DatapartsService } from '../../services/dataparts.service';

@Component({
  selector: 'app-list-asmb-orders',
  templateUrl: './list-asmb-orders.component.html',
  styleUrls: ['./list-asmb-orders.component.css']
})
export class ListAsmbOrdersComponent implements OnInit {

  public orders: any

  constructor(
    private _dataService: DatapartsService
  ) { }

  ngOnInit() {
    this._dataService.getAssemblyOrders()
      .subscribe(data => this.orders = data);
  }

}
