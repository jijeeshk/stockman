import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListAsmbOrdersComponent } from './list-asmb-orders.component';

describe('ListAsmbOrdersComponent', () => {
  let component: ListAsmbOrdersComponent;
  let fixture: ComponentFixture<ListAsmbOrdersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListAsmbOrdersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListAsmbOrdersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
