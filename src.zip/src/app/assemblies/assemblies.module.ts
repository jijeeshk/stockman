import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { AppRoutingModule } from '../app-routing.module';

import { ListAsmbOrdersComponent } from './list-asmb-orders/list-asmb-orders.component';
import { AddAsmbOrdersComponent } from './add-asmb-orders/add-asmb-orders.component';

@NgModule({
  imports: [
    CommonModule,
    AppRoutingModule,
    ReactiveFormsModule,
    NgSelectModule,
    NgbModule
  ],
  declarations: [ListAsmbOrdersComponent, AddAsmbOrdersComponent]
})
export class AssembliesModule { }
