import { AssembliesModule } from './assemblies.module';

describe('AssembliesModule', () => {
  let assembliesModule: AssembliesModule;

  beforeEach(() => {
    assembliesModule = new AssembliesModule();
  });

  it('should create an instance', () => {
    expect(assembliesModule).toBeTruthy();
  });
});
