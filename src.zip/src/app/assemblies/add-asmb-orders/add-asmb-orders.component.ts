import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

import { DatapartsService } from '../../services/dataparts.service';

@Component({
  selector: 'app-add-asmb-orders',
  templateUrl: './add-asmb-orders.component.html',
  styleUrls: ['./add-asmb-orders.component.css']
})
export class AddAsmbOrdersComponent implements OnInit {

  _payLoad: any;
  allProducts: any;
  selectedProduct: any;
  _partsRequired: any;
  partInStock: any;
  data_stock: any;
  _message: any;
  _okOrder: any;

  constructor(
    private _dataService: DatapartsService,
  ) { }

  addAsmbOrderForm = new FormGroup({
    productId: new FormControl(''),
    productCount: new FormControl(''),
    orderDate: new FormControl(''),
    expCompletionDate: new FormControl(''),
    status: new FormControl('New')
  });

  ngOnInit() {
    // For Product drop down
    this.getAllProducts();
  }

  public selected(value: any): void {
    this.selectedProduct = value;
  }

  getAllProducts() {
    this._dataService.getProducts()
      .subscribe(data => this.allProducts = data);
  }

  saveAsmbOrder() {
    this._message = '';
    this._okOrder = true;
    this._payLoad = this.addAsmbOrderForm.value;
    this._payLoad['productName'] = this.selectedProduct.productName;

    // 1.1 Get parts required and count in stock.
    this.getDetails();
  }

  async getDetails() {
    let data = await this._dataService.getProductPartsById(this._payLoad.productId).toPromise();

    for (var i = 0; i <= data.length - 1; i++) {

      this.data_stock = await this._dataService.getstockBypartId(data[i]['parts']['partid']).toPromise();

      if (this.data_stock[0]['partId'] == data[i]['parts']['partid']) {
        if (this.data_stock[0]['partCountVolume'] <= data[i]['parts']['partCountVolume'] * this._payLoad.productCount) {
          this._message = this._message + data[i]['parts']['partName'] + ', ';
          this._okOrder = false;
        }
      }
    }
    if (this._okOrder == true) {
      this._dataService.postAssemblyOrder(this._payLoad)
        .subscribe();
    }
    else {
      alert(this._message + ' is less in stock!..');
    }
  }
}
