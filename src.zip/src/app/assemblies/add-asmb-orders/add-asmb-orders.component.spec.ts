import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddAsmbOrdersComponent } from './add-asmb-orders.component';

describe('AddAsmbOrdersComponent', () => {
  let component: AddAsmbOrdersComponent;
  let fixture: ComponentFixture<AddAsmbOrdersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddAsmbOrdersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddAsmbOrdersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
