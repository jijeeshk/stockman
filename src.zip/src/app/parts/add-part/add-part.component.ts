import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { AlertsService } from 'angular-alert-module';

import { DatapartsService } from '../../services/dataparts.service';

@Component({
  selector: 'app-add-part',
  templateUrl: './add-part.component.html',
  styleUrls: ['./add-part.component.css']
})
export class AddPartComponent implements OnInit {

  _payLoad: any;

  constructor(
    private _dataService: DatapartsService,
    private alerts: AlertsService
  ) { }

  addPartsForm = new FormGroup({
    partName: new FormControl(''),
    partPrice: new FormControl('')
  });

  ngOnInit() {

  }

  saveParts() {
    this._payLoad = JSON.stringify(this.addPartsForm.value);
    this._dataService.postPart(this._payLoad)
      .subscribe(
        (response) => {
          this.alerts.setMessage('New part saved successfully!', 'success');
        },
        error => {
          console.log("Error", error);
        }
      )
  }

}
