import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';
import { AlertsService } from 'angular-alert-module';

import { DatapartsService } from '../../services/dataparts.service';

@Component({
  selector: 'app-edit-part',
  templateUrl: './edit-part.component.html',
  styleUrls: ['./edit-part.component.css']
})
export class EditPartComponent implements OnInit {
  _id: any;
  public _part: any;
  public sub: any;
  public _payLoad: any;

  constructor(
    private _route: ActivatedRoute,
    private _dataService: DatapartsService,
    private alerts: AlertsService
  ) { }

  updatePartsForm = new FormGroup({
    partId: new FormControl(''),
    partName: new FormControl(''),
    partPrice: new FormControl('')
  });

  ngOnInit() {
    this.sub = this._route.params.subscribe(params => {
      this._id = +params['id']; // (+) converts string 'id' to a number

      this._dataService.getPartById(this._id)
        .subscribe(data => {
          this._part = data;
          setTimeout(() => { this.updateValues(this._part) }, 100)
        });
    });

  }

  updateValues(dataObject: any) {
    this.updatePartsForm.setValue({
      partId: this._part.id,
      partName: this._part.partName,
      partPrice: this._part.partPrice
    });
  }

  updateParts() {
    this._payLoad = JSON.stringify(this.updatePartsForm.value);
    this._dataService.editPart(this._payLoad, this._id)
      .subscribe(
        (response) => {
          this.alerts.setMessage('Part updated successfully!', 'success');
        },
        error => {
          alert('Error');
          console.log("Error", error);
        }
      )
  }

}
