export interface IParts {
    id: number,
    title: string,
    price: string
}
