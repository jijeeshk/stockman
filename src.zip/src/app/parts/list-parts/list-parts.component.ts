import { Component, OnInit } from '@angular/core';
import { AlertsService } from 'angular-alert-module';
import {Router} from '@angular/router';

import { DatapartsService } from 'src/app/services/dataparts.service';

@Component({
  selector: 'app-list-parts',
  templateUrl: './list-parts.component.html',
  styleUrls: ['./list-parts.component.css']
})
export class ListPartsComponent implements OnInit {

  public parts = [];
  public part;
  constructor(
    private _dataPartsService: DatapartsService,
    private alerts: AlertsService,
    private router: Router
  ) { }

  ngOnInit() {
    this._dataPartsService.getParts()
      .subscribe(data => this.parts = data);
  }

  deletPart(part) {
    this._dataPartsService.deletPart(part)
      .subscribe(() => {
        this.alerts.setMessage('Select part is deleted successfully!', 'success');
      });
  }

  editPart(part) {
    this.router.navigate(['edit-part',part.id]);
  }

}
