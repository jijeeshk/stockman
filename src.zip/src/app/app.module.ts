import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';

import { NgSelectModule } from '@ng-select/ng-select';
import { AlertsModule } from 'angular-alert-module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

//Services
import { DatapartsService } from './services/dataparts.service';

//Modules
import { AppRoutingModule } from './app-routing.module';
import { PartsModule } from './parts/parts.module';
import { PurchaseModule } from './purchase/purchase.module';
import { ProductsModule } from './products/products.module';
import { AssembliesModule } from './assemblies/assemblies.module';

//Components
import { AppComponent } from './app.component';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    AppRoutingModule,
    ReactiveFormsModule,
    AlertsModule.forRoot(),
    NgSelectModule,
    NgbModule,
    PartsModule,
    PurchaseModule,
    ProductsModule,
    AssembliesModule
  ],
  providers: [DatapartsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
