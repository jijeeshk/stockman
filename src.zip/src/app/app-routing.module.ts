import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PartsModule } from './parts/parts.module';

import { ListPartsComponent } from './parts/list-parts/list-parts.component';
import { AddPartComponent } from './parts/add-part/add-part.component';
import { EditPartComponent } from './parts/edit-part/edit-part.component';
import { ListPurchasesComponent } from './purchase/list-purchases/list-purchases.component';
import { AddPurchaseComponent } from './purchase/add-purchase/add-purchase.component';
import { AddPurchasepartsComponent } from './purchase/add-purchaseparts/add-purchaseparts.component';
import { ListProductsComponent } from './products/list-products/list-products.component';
import { AddProductsComponent } from './products/add-products/add-products.component';
import { ManageProdpartsComponent } from './products/manage-prodparts/manage-prodparts.component';
import { ListAsmbOrdersComponent } from './assemblies/list-asmb-orders/list-asmb-orders.component';
import { AddAsmbOrdersComponent } from './assemblies/add-asmb-orders/add-asmb-orders.component';

const routes: Routes = [
  { path: 'list-parts', component: ListPartsComponent },
  { path: 'add-part', component: AddPartComponent },
  { path: 'edit-part/:id', component: EditPartComponent },
  { path: 'list-purchases', component: ListPurchasesComponent },
  { path: 'add-purchase', component: AddPurchaseComponent },
  { path: 'add-purchase-parts/:id', component: AddPurchasepartsComponent },
  { path: 'list-products', component: ListProductsComponent },
  { path: 'add-products', component: AddProductsComponent },
  { path: 'manage-prodparts/:id', component: ManageProdpartsComponent },
  { path: 'list-assembly-orders', component: ListAsmbOrdersComponent },
  { path: 'add-assembly-order', component: AddAsmbOrdersComponent },
  { path: '', redirectTo: '/list-parts', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
