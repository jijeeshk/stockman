import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { DatapartsService } from '../../services/dataparts.service';

@Component({
  selector: 'app-list-products',
  templateUrl: './list-products.component.html',
  styleUrls: ['./list-products.component.css']
})
export class ListProductsComponent implements OnInit {

  private products = [];

  constructor(
    private _DataService: DatapartsService,
    private router: Router
  ) { }

  ngOnInit() {
    this._DataService.getProducts()
      .subscribe(data => this.products = data);
  }

  manageParts(product) {
    this.router.navigate(['manage-prodparts', product.id]);
  }

}
