export interface IProducts {
    id: number,
    productName: string,
    productPrice: string
}
