import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';

import { AppRoutingModule } from '../app-routing.module';

import { AddProductsComponent } from './add-products/add-products.component';
import { ListProductsComponent } from './list-products/list-products.component';
import { EditProductComponent } from './edit-product/edit-product.component';
import { ManageProdpartsComponent } from './manage-prodparts/manage-prodparts.component';

@NgModule({
  imports: [
    CommonModule,
    AppRoutingModule,
    ReactiveFormsModule,
    NgSelectModule
  ],
  declarations: [AddProductsComponent, ListProductsComponent, EditProductComponent, ManageProdpartsComponent]
})
export class ProductsModule { }
