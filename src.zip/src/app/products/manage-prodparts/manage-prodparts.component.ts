import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormControl, FormGroup } from '@angular/forms';

import { DatapartsService } from '../../services/dataparts.service';

@Component({
  selector: 'app-manage-prodparts',
  templateUrl: './manage-prodparts.component.html',
  styleUrls: ['./manage-prodparts.component.css']
})
export class ManageProdpartsComponent implements OnInit {

  _payLoad: any;
  _formValue: any;
  allParts: any;
  selectedPart: any;
  prodparts: any;
  prodpartsn: any;
  prodId = this._route.snapshot.params.id;
  selectedPartName: any;

  constructor(
    private _dataService: DatapartsService,
    private _route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.getAllParts();
    this.getProductParts();
  }

  addProductPartForm = new FormGroup({
    partid: new FormControl(''),
    partCountVolume: new FormControl('')
  })

  getProductParts() {
    this._dataService.getProductPartsById(this.prodId)
      .subscribe((response) => this.prodparts = response);

  }

  public selected(value: any): void {
    this.selectedPart = value;
  }


  getAllParts() {
    this._dataService.getParts()
      .subscribe(data => this.allParts = data);
  }

  saveProductPart() {
    this._formValue = {};
    this._formValue['parts'] = this.addProductPartForm.value;
    this._formValue['parts']['partName'] = this.selectedPart.partName;
    this._formValue['prodId'] = this.prodId;
    this._payLoad = JSON.stringify(this._formValue);
    console.log(this._payLoad);
    this._dataService.postProductsParts(this._payLoad)
      .subscribe(
        (response) => {
          //this.alerts.setMessage('New part saved successfully!', 'success');
        },
        error => {
          console.log("Error", error);
        }
      )



    //check if product template exists.
    /*this._dataService.getProductPartsById(this.prodId)
      .subscribe(
        (datan) => {
          this.prodpartsn = datan;
          alert("Prod part" + JSON.stringify(this.prodpartsn));
          if (isEmpty(this.prodpartsn)) {
            // Object is empty (Would return true in this example)
            alert('empty');
            this.addTemplate();
          } else {
            // Object is NOT empty
            alert('Not empty');
            this.appendTemplate(this.prodpartsn);
          }

        }
      );

    function isEmpty(obj) {
      for (var key in obj) {
        if (obj.hasOwnProperty(key))
          return false;
      }
      return true;
    }*/

  }

  //Append parts template with new part.
  //get template.
  /* appendTemplate(prodpartsn) {
 
     var oldobj = prodpartsn;
 
     var newData = {
       "productid": "8X",
       "partid": "56X",
       "partName": "klX",
       "partCountVolume": "12X"
     };
     alert("oldobj = " + oldobj[0])
     oldobj[0].parts.push(newData);
 
     console.log(oldobj);
 
     this._payLoad = JSON.stringify(oldobj);
     this._dataService.editProductsParts(this._payLoad, 1)
       .subscribe(
         (response) => {
           //this.alerts.setMessage('Part updated successfully!', 'success');
         },
         error => {
           alert('Error');
           console.log("Error", error);
         }
       ) 
   }*/

}
