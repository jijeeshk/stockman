import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

import { DatapartsService } from '../../services/dataparts.service';

@Component({
  selector: 'app-add-products',
  templateUrl: './add-products.component.html',
  styleUrls: ['./add-products.component.css']
})
export class AddProductsComponent implements OnInit {

  _payLoad: any;

  constructor(
    private _dataService: DatapartsService
  ) { }

  ngOnInit() {
  }

  addProductForm = new FormGroup({
    productName: new FormControl(''),
    productCost: new FormControl('')
  });

  saveProduct() {
    this._payLoad = JSON.stringify(this.addProductForm.value);
    this._dataService.postProducts(this._payLoad)
      .subscribe(
        (response) => {
          //this.alerts.setMessage('New part saved successfully!', 'success');
        },
        error => {
          console.log("Error", error);
        }
      )
  }

}
